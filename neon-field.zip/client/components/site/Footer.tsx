export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-10 grid gap-6 md:grid-cols-3">
        <div>
          <h3 className="font-serif text-xl">Stevens & Acsah</h3>
          <p className="text-sm text-muted-foreground mt-2">Thank you for being part of our celebration.</p>

          <div className="mt-4 flex items-center gap-3">
            <a
              href="https://www.instagram.com/acsah.jos/?igsh=OGczM2VrYnozb3hl"
              target="_blank"
              rel="noreferrer"
              aria-label="Acsah on Instagram"
              className="text-muted-foreground hover:text-foreground"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <rect x="3" y="3" width="18" height="18" rx="5" />
                <circle cx="12" cy="12" r="3" />
                <circle cx="18.5" cy="5.5" r="1" />
              </svg>
            </a>

            <a
              href="https://www.instagram.com/steev_johns/?igsh=andndm1zZmlycmR6&utm_source=qr"
              target="_blank"
              rel="noreferrer"
              aria-label="Steven on Instagram"
              className="text-muted-foreground hover:text-foreground"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <rect x="3" y="3" width="18" height="18" rx="5" />
                <circle cx="12" cy="12" r="3" />
                <circle cx="18.5" cy="5.5" r="1" />
              </svg>
            </a>
          </div>
        </div>

        <div className="md:col-span-2 grid gap-3 md:justify-self-end text-sm text-muted-foreground">
          <div className="flex flex-wrap gap-4">
            <a href="#about" className="hover:text-foreground">Our Story</a>
            <a href="#schedule" className="hover:text-foreground">Schedule</a>
            <a href="#venue" className="hover:text-foreground">Venue</a>
            <a href="#gallery" className="hover:text-foreground">Gallery</a>
            <a href="#rsvp" className="hover:text-foreground">RSVP</a>
          </div>
          <p className="text-xs">© {new Date().getFullYear()} Stevens & Acsah. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
