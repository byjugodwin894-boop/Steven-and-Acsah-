import { RequestHandler } from "express";
import { z } from "zod";
import { RSVPRequest, RSVPResponse } from "@shared/api";

const rsvpSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email(),
  attending: z.enum(["yes", "no"]),
  guests: z.number().int().min(1).max(10),
  message: z.string().max(500).optional().default(""),
});

// Simple in-memory store to demonstrate handling
const RSVPS: Array<RSVPRequest & { createdAt: string }> = [];

export const handleRSVP: RequestHandler = async (req, res) => {
  const parse = rsvpSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: parse.error.flatten().formErrors.join(" ") });
  }
  const data = parse.data;
  RSVPS.push({ ...data, createdAt: new Date().toISOString() });

  // If a Google Sheets webhook URL (for example a Google Apps Script web app URL or Zapier webhook)
  // is provided in the environment, forward the RSVP there as JSON.
  const webhook = process.env.SHEET_WEBHOOK_URL || process.env.SHEETS_WEBHOOK || null;
  if (webhook) {
    try {
      console.log("Forwarding RSVP to webhook:", webhook);
      const payload = { ...data, receivedAt: new Date().toISOString() };
      let resForward;
      // Google Apps Script often expects form-encoded data
      if (webhook.includes("script.google.com")) {
        const params = new URLSearchParams();
        Object.entries(payload).forEach(([k, v]) => params.append(k, String(v ?? "")));
        resForward = await fetch(webhook, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: params.toString(),
        });
      } else {
        resForward = await fetch(webhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }

      if (!resForward.ok) {
        console.error("Webhook responded with non-OK status", resForward.status, await resForward.text());
      } else {
        console.log("Webhook forwarded successfully", await resForward.text());
      }
    } catch (err) {
      console.error("Failed to forward RSVP to sheet webhook:", err);
      // don't fail the request if forwarding fails
    }
  }

  const response: RSVPResponse = { ok: true };
  return res.status(200).json(response);
};
