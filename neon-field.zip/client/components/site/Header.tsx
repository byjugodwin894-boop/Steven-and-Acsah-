import { Link } from "react-router-dom";

const nav = [
  { href: "#about", label: "Our Story" },
  { href: "#schedule", label: "Schedule" },
  { href: "#venue", label: "Venue" },
  { href: "#gallery", label: "Gallery" },
  { href: "#rsvp", label: "RSVP" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <a href="#" className="group inline-flex items-baseline gap-2">
          <span className="text-xl font-serif tracking-tight">Stevens & Acsah</span>
          <span className="text-muted-foreground text-sm group-hover:text-foreground transition-colors">Wedding</span>
        </a>
        <nav className="hidden md:flex items-center gap-6">
          {nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <a
          href="#rsvp"
          className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-emerald-600 to-emerald-500 px-5 py-2 text-sm font-semibold text-white shadow-md transform transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-accent/30 focus:ring-offset-2"
        >
          RSVP
        </a>
      </div>
    </header>
  );
}
