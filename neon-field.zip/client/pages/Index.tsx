import { useEffect, useState } from "react";
import Container from "@/components/site/Container";

interface RSVPForm {
  name: string;
  email: string;
  attending: "yes" | "no";
  guests: number;
  message: string;
}

export default function Index() {
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [form, setForm] = useState<RSVPForm>({
    name: "",
    email: "",
    attending: "yes",
    guests: 1,
    message: "",
  });

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setStatus(null);
    try {
      const res = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Failed to submit");
      setStatus("Thank you! Your RSVP has been recorded.");
      setForm({ name: "", email: "", attending: "yes", guests: 1, message: "" });
    } catch (err: any) {
      setStatus(err.message || "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  };

  // Floral SVG pattern (encoded) to ensure it displays correctly across browsers
  const floralSvg = `<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'><g fill='none' fill-rule='evenodd'><g transform='translate(10,10)' stroke='#d4af37' stroke-opacity='0.18' stroke-width='1.5'><circle cx='30' cy='30' r='6' fill='#d4af37' fill-opacity='0.06'/><circle cx='70' cy='70' r='6' fill='#d4af37' fill-opacity='0.06'/><path d='M10 140 q30 -20 60 0 q30 20 60 0' stroke='#d4af37' stroke-opacity='0.06' fill='none'/></g></g></svg>`;
  const floralDataUrl = `url("data:image/svg+xml;utf8,${encodeURIComponent(floralSvg)}")`;

  return (
    <>
      {/* Hero */}
      <section
        className="relative overflow-hidden bg-cover bg-center min-h-[70vh] md:min-h-screen"
        style={{ backgroundImage: "url('https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F9b7c015a9ce94eaeb6fb2f88cf00d2c1?format=webp&width=2000')" }}
        aria-label="Hero: Stevens & Acsah"
      >
        {/* Decorative floral-like pattern using CSS radial gradients (strong, visible) */}
    <div
      className="absolute inset-0 z-10 pointer-events-none"
      style={{
        backgroundImage: `radial-gradient(circle at 20% 30%, rgba(212,175,55,0.18) 0 8px, transparent 9px), radial-gradient(circle at 70% 70%, rgba(212,175,55,0.12) 0 6px, transparent 7px), radial-gradient(circle at 40% 70%, rgba(212,175,55,0.08) 0 5px, transparent 6px)` ,
        backgroundSize: '220px 220px, 320px 320px, 180px 180px',
        opacity: 0.95,
        mixBlendMode: 'overlay',
      }}
      aria-hidden
    />

    {/* subtle dark overlays for contrast (reduced so pattern shows through) */}
    <div className="absolute inset-0 bg-black/12 z-15" aria-hidden />
    <div className="absolute inset-0 bg-gradient-to-b from-black/6 via-transparent to-black/6 z-15" aria-hidden />

        <Container className="pt-24 pb-24 text-center relative z-20">
          {/* Floating Instagram story bubbles */}
          <div className="absolute top-6 right-6 z-20 flex items-center gap-4">
            <div className="flex flex-col items-center text-center">
              <a
                href="https://www.instagram.com/acsah.jos/?igsh=OGczM2VrYnozb3hl"
                target="_blank"
                rel="noreferrer"
                className="group"
                aria-label="Acsah on Instagram"
              >
                <span className="relative inline-flex">
                  <span className="absolute -inset-0 rounded-full bg-gradient-to-tr from-yellow-300 via-pink-500 to-purple-600 p-0.5 animate-pulse" style={{ filter: "blur(6px)" }} />
                  <span className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-white p-0.5">
                    <img
                      src="https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F77be87572ef04f9f9f6f0ed62cc2d2f6?format=webp&width=300"
                      alt="Acsah"
                      className="h-11 w-11 rounded-full object-cover shadow-md transform transition group-hover:scale-105"
                    />
                  </span>
                </span>
              </a>
              <div className="mt-2 text-xs text-amber-100">
                <div className="font-medium">Bride</div>
                <div className="text-[11px] text-amber-100/80">Acsah</div>
              </div>
            </div>

            <div className="flex flex-col items-center text-center">
              <a
                href="https://www.instagram.com/steev_johns/?igsh=andndm1zZmlycmR6&utm_source=qr"
                target="_blank"
                rel="noreferrer"
                className="group"
                aria-label="Steven on Instagram"
              >
                <span className="relative inline-flex">
                  <span className="absolute -inset-0 rounded-full bg-gradient-to-tr from-yellow-300 via-pink-500 to-purple-600 p-0.5 animate-pulse" style={{ filter: "blur(6px)" }} />
                  <span className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-white p-0.5">
                    <img
                      src="https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F17022b1e07ab463b9a797e0080f7bac9?format=webp&width=300"
                      alt="Steven"
                      className="h-11 w-11 rounded-full object-cover shadow-md transform transition group-hover:scale-105"
                    />
                  </span>
                </span>
              </a>
              <div className="mt-2 text-xs text-amber-100">
                <div className="font-medium">Groom</div>
                <div className="text-[11px] text-amber-100/80">Stevens</div>
              </div>
            </div>
          </div>
          <p className="text-sm tracking-widest uppercase text-muted-foreground">You're invited</p>
          <h1 className="mt-4 text-4xl md:text-6xl font-serif leading-tight text-white">
            The Wedding of <span className="text-emerald-200">Stevens</span> & <span className="text-emerald-200">Acsah</span>
          </h1>
          <p className="mt-4 text-amber-100 max-w-2xl mx-auto">
            Join us for a day of love, laughter, and happily ever after. We can't wait to celebrate together.
          </p>
          <div className="mt-8 hidden md:flex items-center justify-center gap-4">
            <a
              href="#rsvp"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-emerald-600 to-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-md transform transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-accent/30 focus:ring-offset-2"
            >
              RSVP Now
            </a>
            <a href="#schedule" className="text-sm font-medium underline-offset-4 hover:underline text-amber-100">
              View Schedule
            </a>
          </div>
        </Container>
      </section>

      {/* Mobile CTA placed below hero to avoid obscuring faces */}
      <section className="md:hidden py-6">
        <Container>
          <div className="flex flex-col gap-3">
            <a
              href="#rsvp"
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-emerald-600 to-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-md transform transition hover:-translate-y-0.5 focus:outline-none focus:ring-4 focus:ring-accent/30 focus:ring-offset-2"
            >
              RSVP Now
            </a>
            <a href="#schedule" className="text-center text-sm font-medium underline-offset-4 hover:underline">
              View Schedule
            </a>
          </div>
        </Container>
      </section>

      {/* Our Story */}
      <section id="about" className="py-20">
        <Container className="grid items-center gap-10 md:grid-cols-2">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-serif">Our Story</h2>
            <p className="mt-4 text-muted-foreground">
              From a chance meeting to a lifetime together. Our journey has been filled with adventures, laughter, and
              countless memories. We are excited to begin this new chapter surrounded by the people we love most.
            </p>

            {/* Love story timeline */}
            <div className="mt-8">
              <ol className="relative border-l border-muted-foreground/30 pl-6 text-sm">
                <li className="mb-8">
                  <span className="absolute -left-3 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white text-xs">♡</span>
                  <time className="text-xs text-muted-foreground">19/01/2025</time>
                  <h3 className="mt-1 text-lg font-medium">We Met</h3>
                </li>

                <li className="mb-8">
                  <span className="absolute -left-3 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white text-xs">❤</span>
                  <time className="text-xs text-muted-foreground">23/02/2025</time>
                  <h3 className="mt-1 text-lg font-medium">We Fell In Love</h3>
                </li>

                <li className="mb-0">
                  <span className="absolute -left-3 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white text-xs">💍</span>
                  <time className="text-xs text-muted-foreground">13/05/2025</time>
                  <h3 className="mt-1 text-lg font-medium">He Proposed</h3>
                </li>
              </ol>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F17022b1e07ab463b9a797e0080f7bac9?format=webp&width=1200"
              alt="Couple"
              className="aspect-[4/3] w-full rounded-2xl object-cover shadow-lg"
            />
          </div>
        </Container>
      </section>

      {/* Schedule */}
  <section id="schedule" className="py-20 bg-muted/30">
    <Container>
      <h2 className="text-3xl font-serif text-center">Schedule</h2>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {[
          {
            date: "18 December 2025",
            time: "10:30 AM – 12:00 PM",
            title: "Engagement",
            venue: "LA Mirage",
            address: "Old NH, Koratty, Kerala",
            mapUrl: "https://maps.app.goo.gl/uNcn5nJza7sudKMu9",
          },
          {
            date: "22 December 2025",
            time: "10:00 AM – 12:00 PM",
            title: "Wedding",
            venue: "Geetham Auditorium",
            address: "Adoor, Kerala",
            mapUrl: "https://maps.app.goo.gl/XW1TUf2T1givd2bY8?g_st=ia",
          },
        ].map((item) => (
          <div key={item.title} className="rounded-2xl border bg-card p-6 shadow-sm">
            <div className="text-sm text-muted-foreground">{item.date}</div>
            <div className="text-sm text-primary font-semibold">{item.time}</div>
            <div className="mt-2 text-xl font-medium">{item.title}</div>
            <p className="mt-2 text-sm text-muted-foreground">{item.venue} — {item.address}</p>
            <div className="mt-4">
              <a
                className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-4 py-2 text-sm font-medium text-emerald-700 hover:underline"
                href={item.mapUrl}
                target="_blank"
                rel="noreferrer"
              >
                Get Direction
              </a>
            </div>
          </div>
        ))}
      </div>
    </Container>
  </section>

  {/* Venue */}
  <section id="venue" className="py-20">
    <Container className="grid gap-10 md:grid-cols-2">
      <div>
        <h2 className="text-3xl font-serif">Venues</h2>
        <p className="mt-4 text-muted-foreground">
          Below are the venues for our engagement and wedding. Click Get Direction to open maps with directions.
        </p>
        <div className="mt-6 grid gap-4">
          <div className="rounded-xl border p-4">
            <div className="font-medium">LA Mirage</div>
            <div className="text-sm text-muted-foreground">Old NH, Koratty, Kerala</div>
            <a
              className="mt-3 inline-flex items-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-sm font-semibold text-white"
              href="https://maps.app.goo.gl/uNcn5nJza7sudKMu9"
              target="_blank"
              rel="noreferrer"
            >
              Get Direction
            </a>
          </div>
          <div className="rounded-xl border p-4">
            <div className="font-medium">Geetham Auditorium</div>
            <div className="text-sm text-muted-foreground">Adoor, Kerala</div>
            <a
              className="mt-3 inline-flex items-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-sm font-semibold text-white"
              href="https://maps.app.goo.gl/XW1TUf2T1givd2bY8?g_st=ia"
              target="_blank"
              rel="noreferrer"
            >
              GET DIRECTION
            </a>
          </div>
        </div>
      </div>
      <div className="overflow-hidden rounded-2xl border shadow-sm">
        <iframe
          title="Venue Map"
          className="h-80 w-full"
          src={`https://www.google.com/maps?q=${encodeURIComponent("Old NH, Koratty, Kerala")}&output=embed`}
        />
      </div>
    </Container>
  </section>

      {/* Gallery */}
      <section id="gallery" className="py-20 bg-muted/30">
        <Container>
          <h2 className="text-3xl font-serif text-center">Gallery</h2>
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[
              "https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F9b7c015a9ce94eaeb6fb2f88cf00d2c1?format=webp&width=800",
              "https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F77be87572ef04f9f9f6f0ed62cc2d2f6?format=webp&width=800",
              "https://cdn.builder.io/api/v1/image/assets%2Ff0e16400fc5a478f97fa460ba6e3a6d7%2F17022b1e07ab463b9a797e0080f7bac9?format=webp&width=800",
            ].map((src, i) => (
              <img key={i} src={src} alt="Wedding" className="aspect-square w-full rounded-xl object-cover" />
            ))}
          </div>
        </Container>
      </section>

      {/* RSVP */}
      <section id="rsvp" className="py-20">
        <Container>
          <div className="mx-auto max-w-2xl rounded-2xl border bg-card p-8 shadow-sm">
            <h2 className="text-3xl font-serif text-center">RSVP</h2>
            <p className="mt-2 text-center text-sm text-muted-foreground">
              Please let us know if you will be able to join us.
            </p>
            <form className="mt-8 grid gap-4" onSubmit={onSubmit}>
              <div className="grid gap-2 md:grid-cols-2">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Full Name</label>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="h-11 rounded-md border bg-background px-3 outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Your name"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Email</label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="h-11 rounded-md border bg-background px-3 outline-none focus:ring-2 focus:ring-ring"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div className="grid gap-2 md:grid-cols-3">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Attending</label>
                  <select
                    value={form.attending}
                    onChange={(e) => setForm({ ...form, attending: e.target.value as "yes" | "no" })}
                    className="h-11 rounded-md border bg-background px-3 outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="yes">Happily yes</option>
                    <option value="no">Sadly no</option>
                  </select>
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Guests</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={form.guests}
                    onChange={(e) => setForm({ ...form, guests: Number(e.target.value) })}
                    className="h-11 rounded-md border bg-background px-3 outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Message</label>
                  <input
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="h-11 rounded-md border bg-background px-3 outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Optional"
                  />
                </div>
              </div>
              <button
                disabled={submitting}
                className="mt-2 inline-flex items-center justify-center rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow hover:opacity-95 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50"
              >
                {submitting ? "Submitting..." : "Send RSVP"}
              </button>
              {status && (
                <p className="text-sm text-center text-muted-foreground" role="status">
                  {status}
                </p>
              )}
            </form>
          </div>
        </Container>
      </section>
    </>
  );
}
